//
// File: COPSHandle.cc
// Created by: Diogo Gomes <etdgomes@ua.pt>
// Created on: Mon Aug  4 23:54:41 2003
//

#include "COPSHandle.h"

COPSHandle::COPSHandle(const COPSHandle &obj) : COPSObj(obj)
{
	#ifdef DEBUG_MAX
	cerr << "COPSHandle::COPSHandle(const COPSHandle &obj)" << endl;
	#endif
	handle = obj.handle;
}

COPSHandle &COPSHandle::operator=(const COPSHandle &obj)
{
	#ifdef DEBUG_MAX
	cerr << "COPSHandle &operator=(const COPSHandle &obj)" << endl;
	#endif
	(COPSObj) (*this) = obj;
	handle = obj.handle;
}

COPSHandle::COPSHandle(unsigned int h) : COPSObj()
{
	#ifdef DEBUG_MAX
	cerr << "COPSHandle::COPSHandle(unsigned int h)" << endl;
	#endif

	size = calculate_padding(sizeof(struct COPSobj_data)+4);  //obj hdr + 4
	data = new char[size];
	memset(data,0,size);

	struct COPSobj_data *obj;
	obj = ((struct COPSobj_data *) data);
	obj->c_num = Handle;
	obj->c_type = 1;
	obj->obj_len = htons(size);

	handle = htonl(h);
	memcpy((&data[4]),&handle,sizeof(handle));
	handle = h;
}


COPSHandle::~COPSHandle()
{

}
