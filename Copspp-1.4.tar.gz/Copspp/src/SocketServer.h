//
// File: SocketServer.h
// Created by: Diogo Gomes <etdgomes@ua.pt>
// Created on: Thu Jul 31 15:15:36 2003
//

#ifndef _SOCKETSERVER_H_
#define _SOCKETSERVER_H_

#include "Socket.h"

class SocketServer : public Socket
{
	public:
		SocketServer();
		 ~SocketServer();
		bool SocketServer::Bind(const char *server, const char *port);
		bool SocketServer::Listen();
		Socket *Accept();
		
	protected:
};


#endif	//_SOCKETSERVER_H_
