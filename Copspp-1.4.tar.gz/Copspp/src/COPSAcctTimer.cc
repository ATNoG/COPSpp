//
// File: COPSAcctTimer.cc
// Created by: Diogo Gomes <etdgomes@ua.pt>
// Created on: Sun Aug 10 15:43:54 2003
//

#include "COPSAcctTimer.h"

COPSAcctTimer::COPSAcctTimer(const COPSAcctTimer &obj) : COPSObj(obj) 
{
	#ifdef DEBUG_MAX
	cerr << "COPSAcctTimer::COPSAcctTimer(const COPSAcctTimer &obj)" << endl;
	#endif
	ACCTtime = obj.ACCTtime;	
};

COPSAcctTimer &COPSAcctTimer::operator=(const COPSAcctTimer &obj)  
{
	#ifdef DEBUG_MAX
	cerr << "COPSAcctTimer &COPSAcctTimer::operator=(const COPSAcctTimer &obj)" << endl;
	#endif
	(COPSObj) (*this) = obj;	
	ACCTtime = obj.ACCTtime;	
};

COPSAcctTimer::COPSAcctTimer(unsigned int time) : COPSObj()
{
	
	size = calculate_padding(sizeof(struct COPSobj_data)+4);  //obj hdr + 4
	ACCTtime = time;
	data = new char[size];
	memset(data,0,size);

	struct COPSobj_data *obj;
	obj = ((struct COPSobj_data *) data);
	obj->c_num = AcctTimer;
	obj->c_type = 1;
	obj->obj_len = htons(size);

	ACCTtime = htons(time);
	memcpy((&data[6]),&ACCTtime,sizeof(ACCTtime));	// 6 means hdr + 2 octet offset
	ACCTtime = time;
	
}


COPSAcctTimer::~COPSAcctTimer()
{
	// TODO: put destructor code here
}
