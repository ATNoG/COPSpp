//
// File: SocketClient.h
// Created by: Diogo Gomes <etdgomes@ua.pt>
// Created on: Thu Jul 31 15:15:55 2003
//

#ifndef _SOCKETCLIENT_H_
#define _SOCKETCLIENT_H_

#include <Copspp/Socket.h>

class SocketClient : public Socket
{
	public:
		SocketClient();
		 ~SocketClient();
		bool SocketClient::Connect(const char *server, char *port);
		
	protected:
};


#endif	//_SOCKETCLIENT_H_
