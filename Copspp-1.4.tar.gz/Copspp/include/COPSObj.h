//
// File: COPSObj.h
// Created by: Diogo Gomes <etdgomes@ua.pt>
// Created on: Thu Jul 31 21:56:33 2003
//

#ifndef _COPSOBJ_H_
#define _COPSOBJ_H_

#include <netinet/in.h>
#include <string>

struct COPSobj_data {
	unsigned int obj_len:16;
	unsigned int c_num:8;
	unsigned int c_type:8;
};

class COPSmessage;

class COPSObj
{	
	public:
		enum C_num {
			Handle = 1,
			Context = 2,
			INInt = 3,
			OUTInt = 4,
			Reason = 5,
			Decision = 6,
			LPDPDecision = 7,
			Error = 8,
			ClientSI = 9,
			KATimer = 10,
			PEPID = 11,
			ReportType = 12,
			PDPRedirAddr = 13,
			LastPDPAddr = 14,
			AcctTimer = 15,
			Integrity = 16
		};
		
		COPSObj();
		COPSObj(const COPSObj &obj);
		 ~COPSObj();
		friend COPSmessage &operator+(COPSmessage &c, const COPSObj &obj);
		COPSObj &operator=(const COPSObj &);
	
	protected:
		char *data;
		unsigned size;
				
		int calculate_padding(int size);

		unsigned int gSize();
		char *gData();
		
};


#endif	//_COPSOBJ_H_
