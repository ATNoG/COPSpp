//
// File: COPSContext.h
// Created by: Diogo Gomes <etdgomes@ua.pt>
// Created on: Tue Aug  5 00:08:03 2003
//

#ifndef _COPSCONTEXT_H_
#define _COPSCONTEXT_H_

#include <Copspp/COPSObj.h>

struct COPScontext_data {
	unsigned int r_type:16;
	unsigned int m_type:16;
};

class COPSContext : public COPSObj
{
	public:
		enum R_Type {
			IncomingMessage = 0x01,			// Incoming-Message/Admission Control request
			ResourceAllocation = 0x02,		// Resource Allocation request
			OutgoingMessage = 0x04,			// OutgoingMessage request
			ConfigurationRequest = 0x08		// Configuration request
		};
		COPSContext(unsigned short int r_type,unsigned short int m_type=0);
		COPSContext(const COPSContext &);
		COPSContext &operator=(const COPSContext &);
		~COPSContext();
		COPSContext::R_Type getRType();
		unsigned short int getMType();
		bool COPSContext::operator==(COPSContext::R_Type type);

	
	protected:
		R_Type r_type;
		unsigned short int m_type;
};


#endif	//_COPSCONTEXT_H_
