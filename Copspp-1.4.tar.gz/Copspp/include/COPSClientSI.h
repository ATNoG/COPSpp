//
// File: COPSClientSI.h
// Created by: Diogo Gomes <etdgomes@ua.pt>
// Created on: Sat Aug  9 16:57:52 2003
//

#ifndef _COPSCLIENTSI_H_
#define _COPSCLIENTSI_H_

#include <Copspp/COPSObj.h>

class COPSClientSI : public COPSObj
{
	public:
		enum C_Type {
			Signaled = 1,		// Objects/Attributes specific to a client's signaling protocol or internal state
			Named = 2			// Configuration Information useful for relaying specific information about the PEP, a request, or configured state to the PDP server
		};
		COPSClientSI(C_Type type, char *client_data, unsigned int client_data_size);
		COPSClientSI(const COPSClientSI &obj);
		COPSClientSI &operator=(const COPSClientSI &obj);
		 ~COPSClientSI();
		C_Type getType() {return type; };
		unsigned int getSize() { return gSize(); };
		char *getData() { return gData(); };
	
	protected:
		C_Type type;
	
};


#endif	//_COPSCLIENTSI_H_
