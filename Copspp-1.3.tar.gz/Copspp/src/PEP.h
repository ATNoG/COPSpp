//
// File: PEP.h
// Created by: Diogo Gomes <etdgomes@ua.pt>
// Created on: Thu Jul 31 19:10:44 2003
//

#ifndef _PEP_H_
#define _PEP_H_

#include <PThreadsmm/Thread.h>
#include <PThreadsmm/Guard.h>
#include <PThreadsmm/Mutex.h>
#include <PThreadsmm/Condition.h>
#include <PThreadsmm/BlockingQueue.h>

#include <iostream>

#include "SocketClient.h"
#include "COPSmessage.h"
#include "color.h"
#include "config.h"

#define CLIENT_TYPE 0xff02

using namespace std;

typedef BlockingQueue<COPSmessage *> Inbox;

class PEP_exception {
	public:
		PEP_exception(const char *str);
		~PEP_exception() {};
		const std::string what() {return error_msg; };
	private:
		std::string error_msg;
};

class PEPKeepAlive: public Thread {
	public:
		PEPKeepAlive(int debugLvl,Socket *s, unsigned short int ka);
		virtual ~PEPKeepAlive() throw() {};
  		virtual void run() throw();
		void gotKA();
		bool finnished;
	private:
		Mutex lock;	
		Condition KAreply;
		Socket *socket;
		unsigned short int katime;		
		int debugLevel;
};

class PEP : public Thread
{
	public:
		enum inbox {
			solicited_msg=0,
			unsolicited_msg=1
		};
		PEP(int debugLevel,std::string id, std::string pdp_name);
		virtual ~PEP() throw();
		virtual void run() throw();
	
		void Connect(const char *server);
		unsigned int getClientType() {return clientT;};
		
		COPSmessage Receive(inbox box);
		void Send(COPSmessage &msg);
	protected:
		Inbox solicited;
		Inbox unsolicited;
		SocketClient socket;
		long int clientT;
		std::string PepID;
		int katime;
		PEPKeepAlive *keepalive_task;
		std::string pdp;
		Mutex destroy_send;
		Mutex solicited_receive;
		Mutex unsolicited_receive;
	private:
		int debugLevel;
		bool connected;
};


#endif	//_PEP_H_
