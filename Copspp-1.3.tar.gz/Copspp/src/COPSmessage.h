//
// File: COPSmessage.h
// Created by: Diogo Gomes <etdgomes@ua.pt>
// Created on: Thu Jul 31 23:24:01 2003
//

#ifndef _COPSMESSAGE_H_
#define _COPSMESSAGE_H_

#include <iostream>

#include "config.h"

#include "Socket.h"

#include "COPSCommonHeader.h"

#include "COPSObj.h"
#include "COPSPEPID.h"
#include "COPSKATimer.h"
#include "COPSError.h"
#include "COPSHandle.h"
#include "COPSContext.h"
#include "COPSDecision.h"
#include "COPSReportType.h"
#include "COPSReason.h"
#include "COPSClientSI.h"
#include "COPSINInt.h"
#include "COPSOUTInt.h"
#include "COPSAcctTimer.h"
#include "COPSPDPRedirAddr.h"
#include "COPSLastPDPAddr.h"

#define COPS_IP_PROTOCOL "3288"

class COPSmessage_Exception
{
	public:
		COPSmessage_Exception(const char *str);
		COPSmessage_Exception(COPSError::Error_Code err_code);
		~COPSmessage_Exception() {};
		const std::string what() {return error_msg; };
		COPSError::Error_Code error() {return error_code; };
	private:
		std::string error_msg;
		COPSError::Error_Code error_code;
		
};

class COPSmessage
{
	public:
		COPSmessage();
		COPSmessage(const COPSmessage &msg);
		~COPSmessage();
		
		friend COPSmessage &operator+(COPSmessage &c, const COPSCommonHeader &h);
		friend COPSmessage &operator+(COPSmessage &c, const COPSObj &obj);
		friend Socket &operator<<(Socket &socket, const COPSmessage &m);
		friend Socket &operator>>(Socket &socket, COPSmessage &m);
		
		COPSCommonHeader::OpCode getMessageType();	
		bool isValid() {if(size) return true; else return false;};
		operator int() {return getMessageType();};	
		bool operator==(COPSCommonHeader::OpCode code);
		bool operator!=(COPSCommonHeader::OpCode code);
	
		COPSCommonHeader getCOPSCommonHeader() const;
		COPSPEPID getCOPSPEPID() const;
		COPSKATimer getCOPSKATimer() const; 
		COPSHandle getCOPSHandle() const; 
		COPSContext getCOPSContext(unsigned int n=1) const;
		COPSDecision getCOPSDecision(unsigned int n=1) const;		
		COPSReportType getCOPSReportType() const; 
		COPSReason getCOPSReason() const;
		COPSError getCOPSError() const;
		COPSClientSI getCOPSClientSI(unsigned int n=1) const;
		COPSINInt getCOPSINInt() const;
		COPSOUTInt getCOPSOUTInt() const;
		COPSAcctTimer getCOPSAcctTimer() const; 
		COPSPDPRedirAddr getCOPSPDPRedirAddr() const;
		COPSLastPDPAddr getCOPSLastPDPAddr() const;
		
		
		COPSmessage &ClientOpen(unsigned int clientT, std::string PepID);
		COPSmessage &ClientAccept(unsigned int clientT, unsigned int KATime, unsigned int AcctTime=0);
		COPSmessage &ClientClose(unsigned int clientT, COPSError::Error_Code error);
		COPSmessage &Request(unsigned int clientT, unsigned int handle, COPSContext::R_Type rtype, unsigned short int mtype=0);
		COPSmessage &Decision(unsigned int clientT,unsigned int handle, COPSContext::R_Type rtype, unsigned short int mtype, COPSDecision::Command_Code decision);
		COPSmessage &KeepAlive();
		COPSmessage &ReportState(unsigned int clientT, unsigned int handle, COPSReportType::Report_Type type);
		COPSmessage &DeleteRequestState(unsigned int clientT,unsigned int handle, COPSReason::Reason_Code code);
		COPSmessage &SynchronizeStateRequest(unsigned int clientT);
		COPSmessage &SynchronizeStateRequest(unsigned int clientT, unsigned int handle);
		COPSmessage &SynchronizeStateComplete(unsigned int clientT);
		COPSmessage &SynchronizeStateComplete(unsigned int clientT, unsigned int handle);
	
		friend std::ostream &operator<<(std::ostream &o, const COPSmessage &cops);
		
		char *data() {return _data;};	
		unsigned lenght() {return size;};
		
	protected:
		char *_data;
		unsigned size;
	
	private:
		struct COPSobj_data * COPSmessage::FindObject(COPSObj::C_num object, unsigned int pos=1) const;
};


#endif	//_COPSMESSAGE_H_
