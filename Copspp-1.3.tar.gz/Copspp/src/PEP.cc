//
// File: PEP.cc
// Created by: Diogo Gomes <etdgomes@ua.pt>
// Created on: Thu Jul 31 19:10:44 2003
//

#include "PEP.h"
#include "color.h"

PEPKeepAlive::PEPKeepAlive(int debugLvl,Socket *s, unsigned short int ka) : Thread(),KAreply(),socket(s),katime(ka) {
	debugLevel = debugLvl;
	finnished=false;
};

void PEPKeepAlive::run() throw()
{
	try {
		do {
				int vsleep = (int) (katime*(0.25+(0.5*rand()/(RAND_MAX+1.0))));			
				#ifdef DEBUG
				if(debugLevel>=9)
					cerr << "Going to bed (KA)" << endl;
				#endif
				sleep(vsleep);
			
				if(finnished) break;	// no point in continuing if this task is over
				#ifdef DEBUG
				if(debugLevel>=9)
					cerr << "Sending Keep Alive after " << vsleep << " seconds" << endl;	
				#endif	
				COPSmessage ka;
				*socket << ka.KeepAlive();
				if(KAreply.wait(katime*250)) continue; //wait 1/4 of katime for the reply
				#ifdef DEBUG
				if(debugLevel>=5)
					cerr << FG_GREEN << "No reply to Keep Alive sent to the PDP" << RESET << endl;
				#endif
				throw COPSmessage_Exception(COPSError::CommunicationFailure);
			
		} while(!isCanceled());
	} catch (Exception e) {
		#ifdef DEBUG
		if(debugLevel>=5)
			cerr << FG_RED << e.what() << RESET << endl;
		#endif
	} catch (COPSmessage_Exception e) {
		#ifdef DEBUG
		if(debugLevel>=5)
			cerr << FG_GREEN << e.what() << RESET << endl;
		#endif
	} catch (Socket_Exception e) {
		#ifdef DEBUG
		if(debugLevel>=5)
			cerr << FG_RED << e.what() << RESET << endl;
		#endif
	} catch (...) {
		std::cerr << "Something wrong in PEPKeepAlive::Run()" << std::endl;
	}
	#ifdef DEBUG
	if(debugLevel>=5)
		cerr << "PEPKeepAlive::doRun() as left the building" << endl;
	#endif
}

void PEPKeepAlive::gotKA() 
{ 
	try {
		KAreply.signal();
		#ifdef DEBUG
		if(debugLevel>=9)
			cerr << "KAreply.signal()"<< endl;
		#endif 
	} catch (...) {
		std::cerr << "Something wrong in PEPKeepAlive::gotKA()" << std::endl;
	}
};

PEP::PEP(int dbgLevel,std::string id, std::string pdp_name) : Thread()
{
	debugLevel = dbgLevel;
	clientT = CLIENT_TYPE;
	PepID = id;
	pdp = pdp_name;
	katime = -1;		//infinitum
	keepalive_task=NULL;
	connected = false;

	try {
		Connect(pdp.c_str());
		start();
	} catch (Socket_Exception e) {
		throw e;
	} catch (COPSmessage_Exception e) {
		#ifdef DEBUG
		if(debugLevel>=2)
			cerr << "PEP::PEP() " << e.what() << endl;
		#endif
		throw Exception(e.what().c_str());
	} catch (...) {
		std::cerr << FG_RED << "Something wrong in PEP::PEP()" << RESET << std::endl;	
	}
}


PEP::~PEP() throw()
{
	Guard g(&destroy_send);
	Guard g2(&solicited_receive);
	Guard g3(&unsolicited_receive);
	#ifdef DEBUG
	if(debugLevel>=10)
		cerr << "PEP::~PEP()" << endl;
	#endif
	
	try {
		
		if(keepalive_task!=NULL) {	//some times we need to force a clean...
		#ifdef DEBUG
		if(debugLevel>=15)
			cerr << "PEP::~PEP() canceling keepalive_task!" << endl;
		#endif
			keepalive_task->finnished=true;
			keepalive_task->join();
		}
		
		if(connected) {		//clean Exit throw a CLIENT-CLOSE
			connected=false;
			COPSmessage close;	
			socket << close.ClientClose(clientT,COPSError::ShuttingDown);
			if(!solicited.isCanceled())
				solicited.cancel();
			if(!unsolicited.isCanceled())
				unsolicited.cancel();
		}

	} catch (Exception e) {
		#ifdef DEBUG
		if(debugLevel>=2)
			cerr << "PEP::~PEP() Exception: " << e.what() << endl;
		#endif	
	} catch (...) {
		#ifdef DEBUG
		if(debugLevel>=2)
			cerr << "PEP::~PEP() problems...." << endl;	
		#endif	
	}
	#ifdef DEBUG
	if(debugLevel>=16)
		cerr << "PEP::~PEP() DONE" << endl;
	#endif
	delete keepalive_task;
}

void PEP::run() throw() {
	try {
		#ifdef DEBUG
		if(debugLevel>=2)
			cerr << "PEP Started" << endl;
		#endif	
		
		while(socket.Poll(katime*1000) && connected) {		// we should at least receive a message each KA time or we must be dead :D
			#ifdef DEBUG
			if(debugLevel>=7)
				cerr << "got something" << endl;
			#endif
			COPSmessage msg;
			socket >> msg;
		
			switch(msg) {
				case COPSCommonHeader::KEEP_ALIVE: 
					#ifdef DEBUG
					if(debugLevel>=3)
						cerr << "Received KEEP ALIVE from PDP" << endl;
					#endif
					keepalive_task->gotKA();
					break;	
				case COPSCommonHeader::CLIENT_CLOSE:
					#ifdef DEBUG
					if(debugLevel>=3)
						cerr << "Received CLIENT CLOSE from PDP" << endl;
					#endif
					connected = false;
					throw Socket_Exception("PDP closed remote socket");
					break;
				case COPSCommonHeader::DECISION:
					#ifdef DEBUG
					if(debugLevel>=3)
						cerr << "Received DECISION from PDP" << endl;
					#endif
					if(msg.getCOPSCommonHeader().isUnsolicited()) {
						#ifdef DEBUG
						if(debugLevel>=5)
							cerr << "Unsolicited DECISION" << endl;
						#endif
						unsolicited.add(new COPSmessage(msg));
					}
					else {
						#ifdef DEBUG
						if(debugLevel>=5)
							cerr << "Solicited DECISION" << endl;
						#endif
						solicited.add(new COPSmessage(msg));
					}
					break;
				default:
					solicited.add(new COPSmessage(msg));
				
			}		
		}
		#ifdef DEBUG
		if(debugLevel>=10)
			cerr << "Clean Exit from PEP main loop" << endl;
		#endif
	} catch (COPSmessage_Exception e) {
		#ifdef DEBUG
		if(debugLevel>=3)
			cerr << "Exception " << e.what() << " lead to Close Client" << endl;
		#endif
		throw e;
	} catch (Socket_Exception e) {
		#ifdef DEBUG
		if(debugLevel>=5)
			cerr << FG_RED << "PEP::run() : " <<  e.what() << RESET << endl;
		#endif	
		connected = false;
		try {
			if(!keepalive_task->finnished) {
				keepalive_task->finnished=true;	// no more need for keep alives
				keepalive_task->join();
			}
			#ifdef DEBUG
			if(debugLevel>=9)
				cerr << FG_RED << " (done)" << RESET << endl;
			#endif	
		} catch (Exception e) {
			#ifdef DEBUG
			if(debugLevel>=5)
				cerr << "Exception trying to cancel keep alive : " << e.what() << endl;
			#endif
		} catch (...) {
			#ifdef DEBUG
			if(debugLevel>=5)
				cerr << "Unknown Exception trying to cancel keep alive : " << endl;
			#endif
		}
		solicited.cancel();
		unsolicited.cancel();
	} catch (...) {
		std::cerr << FG_RED << "Something wrong in PEP::run()" << RESET << std::endl;	
	}
	#ifdef DEBUG
	if(debugLevel>=9)	
		cerr << FG_RED << "PEP::run() all done" << RESET << endl;
	#endif
}

void PEP::Connect(const char *server) 
{
	socket.Connect(server,COPS_IP_PROTOCOL);
	
	COPSmessage open;
	socket << open.ClientOpen(clientT,PepID);
	#ifdef DEBUG
	if(debugLevel>=2)
		cerr << "Opened connection with " << server << endl;
	#endif
	COPSmessage reply;
	socket >> reply;
	
	if(reply==COPSCommonHeader::CLIENT_ACCEPT) {
		#ifdef DEBUG
		if(debugLevel>=2)
			cerr << "We were Accepted" << endl;
		#endif
		katime = reply.getCOPSKATimer().getKAtime();
		keepalive_task = new PEPKeepAlive(debugLevel,&socket,katime);
		keepalive_task->start();
		connected = true;
	} else throw COPSmessage_Exception(COPSError::BadMessageFormat);
}

COPSmessage PEP::Receive(inbox box) 
{
	COPSmessage *t = NULL;

	try {
		if(box==solicited_msg) {
			Guard g(&solicited_receive);
			t = solicited.next();	//next() leaves you charge of freeing t
			COPSmessage m(*t);
			delete t;		//soo lets clean it ;)
			return m;
		} else {
			Guard g(&unsolicited_receive);
			t = unsolicited.next();
			COPSmessage m(*t);
			delete t;		//soo lets clean it ;)
			return m;
		}
	} catch(Cancel_Exception e) {
		throw COPSmessage_Exception("Connection with PDP lost");
		/* we expect this since it means PEP exited without leaving any message in inbox */
	} catch(Exception e) {
		std::cerr << FG_RED << e.what() << RESET << std::endl;
	} catch (...) {
		std::cerr << FG_RED << "PEP::Receive() big mess" << RESET << std::endl;
	}
	#ifdef DEBUG
	if(debugLevel>=5)
		cerr << "PEP::Receive did not find any message in his inbox" << endl;
	#endif
	return COPSmessage();
}

void PEP::Send(COPSmessage &msg)
{
	Guard g(&destroy_send);
	try {
		socket << msg;
	} catch (Socket_Exception e) {
		std::cerr << e.what() << std::endl;
	}
}
