//
// File: PDPchild.h
// Created by: Diogo Gomes <etdgomes@ua.pt>
// Created on: Sun Aug  3 01:24:50 2003
//

#ifndef _PDPCHILD_H_
#define _PDPCHILD_H_

#include <PThreadsmm/Thread.h>
#include <PThreadsmm/Guard.h>
#include <PThreadsmm/BlockingQueue.h>

#include <iostream>
#include <map>

#include <Copspp/Socket.h>
#include <Copspp/COPSmessage.h>

typedef BlockingQueue<COPSmessage *> Inbox;

class PDPchild : public Thread
{
	public:
		PDPchild(int debugLevel, Socket *sock, std::string pep,unsigned int clientT, int Timeout);
		virtual ~PDPchild() throw();
		virtual void run() throw();
		virtual void cancel() throw();
		bool isConnected() {return connected;};	
		std::string getID() {return pepid;};
		COPSmessage Receive(unsigned long timeout=0);
		void Send(COPSmessage &msg);
		Inbox inbox;
		unsigned int getClientType(){return clientT;};

	protected:
		Socket *socket;
		int timeout;
		bool connected;
		bool close;
		unsigned int clientT;
		Mutex destroy;
		std::string pepid;
};


#endif	//_PDPCHILD_H_
