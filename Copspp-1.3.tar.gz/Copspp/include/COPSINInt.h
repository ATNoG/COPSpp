//
// File: COPSINint.h
// Created by: Diogo Gomes <dgomes@av.it.pt>
// Created on: Sat Aug  9 21:11:42 2003
//

#ifndef _COPSININT_H_
#define _COPSININT_H_

#include <Copspp/COPSObj.h>

class COPSINInt : public COPSObj
{
	public:
		enum AddressType {
			IP4 = 1,
			IP6 = 2
		};
		COPSINInt(in_addr *ip4, unsigned int ifind);
		COPSINInt(in6_addr *ip6, unsigned int ifind);
		COPSINInt(const COPSINInt &obj) : COPSObj(obj) {
			ifindex = obj.ifindex; 
			if(obj.isIPv4()) memcpy(&ipv4,&(obj.ipv4),sizeof(in_addr));
			if(obj.isIPv6()) memcpy(&ipv6,&(obj.ipv6),sizeof(in6_addr));
		};
		 ~COPSINInt();
		in_addr getIPv4();
		in6_addr getIPv6();
		bool isIPv4() const;
		bool isIPv6() const;
		unsigned int getIfIndex() {return ifindex; };
	
	protected:
		unsigned int ifindex;
		union {
			in_addr ipv4;
			in6_addr ipv6;
		};
		
	
};


#endif	//_COPSININT_H_
