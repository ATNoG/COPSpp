//
// File: COPSOUTInt.h
// Created by: Diogo Gomes <etdgomes@ua.pt>
// Created on: Sat Aug  10 15:27:42 2003
//

#ifndef _COPSOUTINT_H_
#define _COPSOUTINT_H_

#include <Copspp/COPSObj.h>

class COPSOUTInt : public COPSObj
{
	public:
		enum AddressType {
			IP4 = 1,
			IP6 = 2
		};
		COPSOUTInt(in_addr *ip4, unsigned int ifind);
		COPSOUTInt(in6_addr *ip6, unsigned int ifind);
		COPSOUTInt(const COPSOUTInt &obj) : COPSObj(obj) {
			ifindex = obj.ifindex; 
			if(obj.isIPv4()) memcpy(&ipv4,&(obj.ipv4),sizeof(in_addr));
			if(obj.isIPv6()) memcpy(&ipv6,&(obj.ipv6),sizeof(in6_addr));
		}
		 ~COPSOUTInt();
		in_addr getIPv4();
		in6_addr getIPv6();
		bool isIPv4() const;
		bool isIPv6() const;
		unsigned int getIfIndex() {return ifindex; };
	
	protected:
		unsigned int ifindex;
		union {
			in_addr ipv4;
			in6_addr ipv6;
		};
		
	
};


#endif	//_COPSOUTINT_H_
