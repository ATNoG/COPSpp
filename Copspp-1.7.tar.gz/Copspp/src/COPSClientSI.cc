//
// File: COPSClientSI.cc
// Created by: Diogo Gomes <etdgomes@ua.pt>
// Created on: Sat Aug  9 16:57:52 2003
//

#include "COPSClientSI.h"

COPSClientSI::COPSClientSI(const COPSClientSI &obj) : COPSObj(obj) 
{
	#ifdef DEBUG_MAX
	cerr << "COPSClientSI::COPSClientSI(const COPSClientSI &obj)" << endl;
	#endif
	type = obj.type; 
};

COPSClientSI &COPSClientSI::operator=(const COPSClientSI &obj) 
{
	#ifdef DEBUG_MAX
	cerr << "COPSClientSI &COPSClientSI::operator=(const COPSClientSI &obj)" << endl;
	#endif
	COPSObj::operator=(obj);
	type = obj.type;
	return *this;
};


COPSClientSI::COPSClientSI(C_Type t,const COPSObj &cops_obj)
{
	size = calculate_padding(sizeof(struct COPSobj_data)+cops_obj.size);  
	type = t;
	data= new char[size];
	memset(data,0,size);
	
	struct COPSobj_data * obj;
	obj = ((struct COPSobj_data *) data);
	obj->c_num = ClientSI;
	obj->c_type = (unsigned short int) type;
	obj->obj_len = htons(size);
	
	memcpy(&data[4],cops_obj.data,cops_obj.size);
	
}

COPSObj COPSClientSI::getCOPSObj() const
{
	COPSObj obj;
	// 4 is COPSClientSI header we need to read COPSObj header
	obj.size = size-4;
	obj.data = new char[obj.size];
	memcpy(obj.data,&data[4],obj.size);

	return obj;
}

COPSClientSI::COPSClientSI(C_Type t, char *client_data, unsigned int client_data_size) : COPSObj()
{
	#ifdef DEBUG_MAX
	cerr << "COPSClientSI::COPSClientSI(C_Type t, char *client_data, unsigned int client_data_size)" << endl;
	#endif
	size = calculate_padding(sizeof(struct COPSobj_data)+client_data_size);  //obj hdr + 4
	type = t;
	data= new char[size];
	memset(data,0,size);
	
	struct COPSobj_data * obj;
	obj = ((struct COPSobj_data *) data);
	obj->c_num = ClientSI;
	obj->c_type = (unsigned short int) type;
	obj->obj_len = htons(size);
	
	
	memcpy(&data[4],client_data,client_data_size);
}

COPSClientSI::~COPSClientSI()
{
}
