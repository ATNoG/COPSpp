//
// File: COPSObj.cc
// Created by: Diogo Gomes <etdgomes@ua.pt>
// Created on: Thu Jul 31 21:56:33 2003
//

#include "COPSObj.h"


COPSObj::COPSObj()
{
	#ifdef DEBUG_MAX
	std::cerr << "COPSObj::COPSObj() = "<< std::hex << this << std::dec << std::endl;
	#endif
	size=0;
	data = NULL;
}

COPSObj::COPSObj(const COPSObj &obj)
{
	#ifdef DEBUG_MAX
	std::cerr << "COPSObj::COPSObj(const COPSObj &) "<< std::hex << this <<  "= "<< &obj << std::dec << std::endl;
	#endif
	size=obj.size;
	data = new char[size];
	memcpy(data,obj.data,size);
}

COPSObj &COPSObj::operator=(const COPSObj &obj)
{
	#ifdef DEBUG_MAX
	std::cerr << "COPSObj &COPSObj::operator=(const COPSObj &obj) "<< std::hex << this <<  "= "<< &obj << std::dec << std::endl;
	#endif
	if(this!=&obj) {	// avoid self assignment
		size=obj.size;
		if(data!=NULL) delete data;
		data = new char[size];
		memcpy(data,obj.data,size);
	}
	return *this;
}


COPSObj::~COPSObj()
{
	#ifdef DEBUG_MAX
	std::cerr << "COPSObj::~COPSObj()= "<< std::hex << this << std::dec << std::endl;
	#endif
	if(data!=NULL)
		delete [] data;
	data = NULL;
}

int COPSObj::calculate_padding(int size) {
	int d;
	if((d=size%4)==0) {
		return size;
	} else {
		return size+(4-d);
	}
}

unsigned int COPSObj::gSize()
{ 
	return (size - sizeof(struct COPSobj_data));
}

char *COPSObj::gData()
{ 
	return ((char *)data+ sizeof(struct COPSobj_data)); 
}
