//
// File: COPSPEPID.h
// Created by: Diogo Gomes <etdgomes@ua.pt>
// Created on: Thu Jul 31 21:52:18 2003
//

#ifndef _COPSPEPID_H_
#define _COPSPEPID_H_

#include "COPSObj.h"

class COPSPEPID : public COPSObj
{
	public:
		COPSPEPID();
		COPSPEPID(std::string identifier);
		COPSPEPID(const COPSPEPID &);
		COPSPEPID &operator=(const COPSPEPID &);
		~COPSPEPID();
		std::string getId() {return id;};
	
	protected:
		std::string id;
	
};


#endif	//_COPSPEPID_H_
