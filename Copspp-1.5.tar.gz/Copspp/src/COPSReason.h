//
// File: COPSReason.h
// Created by: Diogo Gomes <etdgomes@ua.pt>
// Created on: Sat Aug  9 15:22:16 2003
//

#ifndef _COPSREASON_H_
#define _COPSREASON_H_

#include "COPSObj.h"

class COPSReason : public COPSObj
{
	public:
		enum Reason_Code {
			Unspecified = 1,
			Management = 2,
			Preempted = 3, 	// Another request state takes precedence
			Tear = 4, 		// Used to communicate a signaled state removal
			Timeout = 5, 	// Local State has timed-out
			RouteChange = 6, 	// Change invalidates request state
			InsufficientResources = 7,  //No local resource available
			PDPDirective = 8, 	//PDP decision caused the delete
			UnsupportedDecision = 9, //PDP decision not supported
			SynchronizeHandleUnknown = 10,
			TransientHandle = 11, //stateless event
			MalformedDecision = 12, 	//could not recover
			UnknownCOPSObjectFromPDP = 13 //Sub-code (octet 2) contains unknown object's C-Num and octet 3 contains unknown objects C-Type
		};
		COPSReason(Reason_Code code, unsigned int subcode=0);
		COPSReason(const COPSReason &);
		COPSReason &operator=(const COPSReason &);
		~COPSReason();
		Reason_Code getCode() { return code; };
	
	protected:
		Reason_Code code;
		unsigned short int sub_code;
	
};


#endif	//_COPSREASON_H_
