#!/bin/bash
diff -u $1 ../src/$1
