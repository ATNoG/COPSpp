//
// File: COPSAcctTimer.h
// Created by: Diogo Gomes <etdgomes@ua.pt>
// Created on: Sun Aug 10 15:43:54 2003
//

#ifndef _COPSACCTTIMER_H_
#define _COPSACCTTIMER_H_

#include "COPSObj.h"

class COPSAcctTimer : public COPSObj
{
	public:
		COPSAcctTimer(unsigned int time);
		 ~COPSAcctTimer();
		unsigned short getACCTtime() {return ACCTtime;};
	
	protected:
		unsigned short ACCTtime;
};

#endif	//_COPSACCTTIMER_H_
