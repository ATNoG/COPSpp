//
// File: COPSHandle.h
// Created by: Diogo Gomes <etdgomes@ua.pt>
// Created on: Mon Aug  4 23:54:40 2003
//

#ifndef _COPSHANDLE_H_
#define _COPSHANDLE_H_

#include "COPSObj.h"

class COPSHandle : public COPSObj
{
	public:
		COPSHandle(unsigned int h);
		 ~COPSHandle();
		unsigned int getHandle() {return handle;};
	
	protected:
		unsigned int handle;
};


#endif	//_COPSHANDLE_H_
