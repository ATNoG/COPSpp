//
// File: COPSReportType.cc
// Created by: Diogo Gomes <etdgomes@ua.pt>
// Created on: Thu Aug  7 22:54:40 2003
//

#include "COPSReportType.h"


COPSReportType::COPSReportType(Report_Type t) : COPSObj()
{
	size = calculate_padding(sizeof(struct COPSobj_data)+4);  //obj hdr + 4
	type = t;
	data = new char[size];
	memset(data,0,size);

	struct COPSobj_data *obj;
	obj = ((struct COPSobj_data *) data);
	obj->c_num = ReportType;
	obj->c_type = 1;
	obj->obj_len = htons(size);

	type = (Report_Type) htons(t);
	memcpy((&data[4]),&type,sizeof(type));
	type = t;
}


COPSReportType::~COPSReportType()
{

}
