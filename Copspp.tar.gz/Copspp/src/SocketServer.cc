//
// File: SocketServer.cc
// Created by: Diogo Gomes <etdgomes@ua.pt>
// Created on: Thu Jul 31 15:15:36 2003
//

#include "SocketServer.h"


SocketServer::SocketServer() : Socket()
{
}

bool SocketServer::Bind(const char *server, const char *port) 
{
	struct addrinfo hints, *res, *res0;
	int error;
	Guard g(&mutex);
	memset(&hints, 0, sizeof(hints));
	
	hints.ai_family = UNSPEC;
	hints.ai_socktype = STREAM;
	hints.ai_flags = AI_PASSIVE;
	if((error = getaddrinfo(server, port, &hints, &res0))!=0) throw Socket_Exception((char *)gai_strerror(error));

	close(sockfd);
	for (res = res0; res; res = res->ai_next) {
		if((sockfd=socket(res->ai_family, res->ai_socktype,res->ai_protocol))<0) {
			continue;
		}
		if (bind(sockfd, res->ai_addr, res->ai_addrlen) >= 0) {
			freeaddrinfo(res0);
	        return true;   
		}
	}
    throw Socket_Exception(strerror(errno));
    freeaddrinfo(res0);
}

bool SocketServer::Listen() 
{
	Guard g(&mutex);
	if (listen(sockfd, SOMAXCONN) < 0) {
		throw Socket_Exception(strerror(errno));        
	}	
	return true;   
}

Socket *SocketServer::Accept() {
   size_t sin_size = sizeof(struct sockaddr);
   sockaddr RemoteAddress;
   int newfd;
   
   Guard g(&mutex);
   if((newfd = accept(sockfd, (struct sockaddr *)&RemoteAddress, &sin_size)) == -1) {
      throw Socket_Exception(strerror(errno));        
   }
   return new Socket(newfd);

}

SocketServer::~SocketServer()
{
	// TODO: put destructor code here
}
