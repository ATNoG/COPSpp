/* Created by Anjuta version 1.1.97 */
/*	This file will not be overwritten */
/*
	DUMMY MAIN
*/
