//
// File: COPSPEPID.cc
// Created by: Diogo Gomes <etdgomes@ua.pt>
// Created on: Thu Jul 31 21:52:18 2003
//

#include "COPSPEPID.h"

COPSPEPID::COPSPEPID() : COPSObj()
{
	id = "";
}

COPSPEPID::COPSPEPID(std::string identifier) : COPSObj()
{
	size = calculate_padding(sizeof(struct COPSobj_data)+identifier.size()+1);  //obj hdr + (identifier + \0)
	id = identifier;
	data= new char[size];
	memset(data,0,size);
	
	struct COPSobj_data *obj;
	obj = ((struct COPSobj_data *) data);
	obj->c_num = PEPID;
	obj->c_type = 1;
	obj->obj_len = htons(size);
	
	memcpy(&data[4],id.c_str(),id.size());
	char null_char  = '\0';
	memcpy(&data[4+id.size()],&null_char,1);
}

COPSPEPID::~COPSPEPID()
{

}
