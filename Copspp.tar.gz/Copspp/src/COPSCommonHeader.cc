//
// File: COPSCommonHeader.cc
// Created by: Diogo Gomes <etdgomes@ua.pt>
// Created on: Thu Jul 31 18:53:18 2003
//

#include "COPSCommonHeader.h"

//#include <iostream>

COPSCommonHeader::COPSCommonHeader(OpCode code, unsigned int clientType)
{
	((struct COPScommon_hdr *)_data) = new char[sizeof(struct COPScommon_hdr)];
	((struct COPScommon_hdr *)_data)->version = COPS_VERSION;
	((struct COPScommon_hdr *)_data)->flags = SOLICITED;
	((struct COPScommon_hdr *)_data)->op_code = code;
	((struct COPScommon_hdr *)_data)->client_type = htons(clientType);
	((struct COPScommon_hdr *)_data)->message_len = htonl(sizeof(struct COPScommon_hdr));
	size = sizeof(struct COPScommon_hdr);
}

unsigned int COPSCommonHeader::getClientT() 
{
	return ntohs(((struct COPScommon_hdr *) _data)->client_type);
}

COPSCommonHeader::OpCode COPSCommonHeader::getOpCode() 
{
	return (OpCode) ((struct COPScommon_hdr *)_data)->op_code;
};

unsigned int COPSCommonHeader::message_len() 
{
	return ntohl(((struct COPScommon_hdr *)_data)->message_len);
};

bool COPSCommonHeader::isUnsolicited()
{
	if(((struct COPScommon_hdr *)_data)->flags == UNSOLICITED) return true;
	return false;
}

bool COPSCommonHeader::valid() 
{
	if(((struct COPScommon_hdr *)_data)->version!= COPS_VERSION) return false;
	if(((struct COPScommon_hdr *)_data)->flags!=SOLICITED && ((struct COPScommon_hdr *)_data)->flags!=UNSOLICITED) return false;
	if(((struct COPScommon_hdr *)_data)->op_code<REQUEST || ((struct COPScommon_hdr *)_data)->op_code>SYNCHRONIZE_COMPLETE) return false;
	if(ntohl(((struct COPScommon_hdr *)_data)->message_len)%4!=0) return false;
	return true;
}

COPSCommonHeader::COPSCommonHeader()
{
	((struct COPScommon_hdr *)_data) = new (struct COPScommon_hdr)[1];
	memset(_data,0,sizeof(struct COPScommon_hdr));
	size = sizeof(struct COPScommon_hdr);
}

COPSCommonHeader::COPSCommonHeader(char *data)
{
	if(data!=NULL) {
		((struct COPScommon_hdr *)_data) = new (struct COPScommon_hdr)[1];
		memcpy(_data,data,sizeof(struct COPScommon_hdr));
		size = sizeof(struct COPScommon_hdr);	
	} else {
		((struct COPScommon_hdr *)_data) = new (struct COPScommon_hdr)[1];
		memset(_data,0,sizeof(struct COPScommon_hdr));
		size = sizeof(struct COPScommon_hdr);
	}
}

COPSCommonHeader::COPSCommonHeader(COPSCommonHeader &hdr)
{
	size=hdr.size;
	_data = new char[size];
	memcpy(_data,hdr._data,size);
}

COPSCommonHeader::~COPSCommonHeader()
{
	delete [] ((struct COPScommon_hdr*)_data);
}
