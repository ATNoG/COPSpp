//
// File: COPSINint.cc
// Created by: Diogo Gomes <etdgomes@ua.pt>
// Created on: Sat Aug  9 21:11:42 2003
//

#include "COPSINInt.h"

COPSINInt::COPSINInt(in_addr *ip4, unsigned int ifind) : COPSObj()
{
	size = calculate_padding(sizeof(struct COPSobj_data)+sizeof(in_addr)+sizeof(unsigned int));  //obj hdr + 4
	data= new char[size];
	memset(&ipv6,0,sizeof(in6_addr));
	
	struct COPSobj_data * obj;
	obj = ((struct COPSobj_data *) data);
	obj->c_num = INInt;
	obj->c_type = IP4; //ipv4
	obj->obj_len = htons(size);
	
	memcpy(&data[4],ip4,sizeof(in_addr));
	memcpy(&ipv4,ip4,sizeof(in_addr));
	ifindex = htonl(ifind);
	memcpy(&data[8],&ifindex,sizeof(unsigned int));
	ifindex = ifind;
}

COPSINInt::COPSINInt(in6_addr *ip6, unsigned int ifind) : COPSObj()
{
	size = calculate_padding(sizeof(struct COPSobj_data)+sizeof(in6_addr)+sizeof(unsigned int));  //obj hdr + 4
	data= new char[size];
	memset(&ipv4,0,sizeof(in_addr));
	
	struct COPSobj_data * obj;
	obj = ((struct COPSobj_data *) data);
	obj->c_num = INInt;
	obj->c_type = IP6; //ipv6
	obj->obj_len = htons(size);
	
	memcpy(&data[4],ip6,sizeof(in6_addr));
	memcpy(&ipv6,ip6,sizeof(in6_addr));
	ifindex = htonl(ifind);
	memcpy(&data[20],&ifindex,sizeof(unsigned int));
	ifindex = ifind;
}

in_addr COPSINInt::getIPv4() {
	return ipv4;
}

in6_addr COPSINInt::getIPv6() {
	return ipv6;
}

bool COPSINInt::isIPv4() {
	if(((struct COPSobj_data *) data)->c_type == IP4) return true;
	return false;
}

bool COPSINInt::isIPv6() {
	if(((struct COPSobj_data *) data)->c_type == IP6) return true;
	return false;
}

COPSINInt::~COPSINInt()
{
	// TODO: put destructor code here
}
