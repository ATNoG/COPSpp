//
// File: COPSClientSI.cc
// Created by: Diogo Gomes <etdgomes@ua.pt>
// Created on: Sat Aug  9 16:57:52 2003
//

#include "COPSClientSI.h"


COPSClientSI::COPSClientSI(C_Type t, char *client_data, unsigned int client_data_size) : COPSObj()
{
	size = calculate_padding(sizeof(struct COPSobj_data)+client_data_size);  //obj hdr + 4
	type = t;
	data= new char[size];
	memset(data,0,size);
	
	struct COPSobj_data * obj;
	obj = ((struct COPSobj_data *) data);
	obj->c_num = ClientSI;
	obj->c_type = (unsigned short int) type;
	obj->obj_len = htons(size);
	
	
	memcpy(&data[4],client_data,client_data_size);
}

COPSClientSI::~COPSClientSI()
{
	// TODO: put destructor code here
}
