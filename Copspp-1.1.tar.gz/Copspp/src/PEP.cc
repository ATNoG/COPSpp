//
// File: PEP.cc
// Created by: Diogo Gomes <etdgomes@ua.pt>
// Created on: Thu Jul 31 19:10:44 2003
//

#include "PEP.h"
#include "color.h"

PEPKeepAlive::PEPKeepAlive(int debugLevel,Socket *s, unsigned short int ka) : Thread(),KAreply(),socket(s),katime(ka) {
	lerr << logstream::setDebugLevel(debugLevel);
	finnished=false;
};

void PEPKeepAlive::run() throw()
{
	try {
		do {
				int vsleep = (int) (katime*(0.25+(0.5*rand()/(RAND_MAX+1.0))));			
				logstream::lerr << logstream::level(9) << "Going to bed (KA)" << logstream::endl;
				sleep(vsleep);
			
				if(finnished) break;	// no point in continuing if this task is over
				logstream::lerr << logstream::level(9) << "Sending Keep Alive after " << vsleep << " seconds" << logstream::endl;	
				
				COPSmessage ka;
				*socket << ka.KeepAlive();
				if(KAreply.wait(katime*250)) continue; //wait 1/4 of katime for the reply
				logstream::lerr << logstream::level(5) << FG_GREEN << "No reply to Keep Alive sent to the PDP" << RESET << logstream::endl;
				throw COPSmessage_Exception(COPSError::CommunicationFailure);
			
		} while(!isCanceled());
	} catch (Exception e) {
		logstream::lerr << logstream::level(5) << FG_RED << e.what() << RESET << logstream::endl;
	} catch (COPSmessage_Exception e) {
		logstream::lerr << logstream::level(5) << FG_GREEN << e.what() << RESET << logstream::endl;
	} catch (Socket_Exception e) {
		logstream::lerr << logstream::level(5) << FG_RED << e.what() << RESET << logstream::endl;
	} catch (...) {
		std::cerr << "Something wrong in PEPKeepAlive::Run()" << std::endl;
	}
	logstream::lerr << logstream::level(5) << "PEPKeepAlive::doRun() as left the building" << logstream::endl;
}

void PEPKeepAlive::gotKA() 
{ 
	try {
		KAreply.signal();
		logstream::lerr << logstream::level(9) << "KAreply.signal()"<< logstream::endl; 
	} catch (...) {
		std::cerr << "Something wrong in PEPKeepAlive::gotKA()" << std::endl;
	}
};

PEP::PEP(int dbgLevel,std::string id, std::string pdp_name) : Thread()
{
	debugLevel = dbgLevel;
	lerr << logstream::setDebugLevel(debugLevel);
	clientT = CLIENT_TYPE;
	PepID = id;
	pdp = pdp_name;
	katime = -1;		//infinitum
	keepalive_task=NULL;
	connected = false;

	try {
		Connect(pdp.c_str());
		start();
	} catch (Socket_Exception e) {
		throw e;
	} catch (COPSmessage_Exception e) {
		lerr << logstream::level(2) << "PEP::PEP() " << e.what() << logstream::endl;
		throw Exception(e.what().c_str());
	} catch (...) {
		std::cerr << FG_RED << "Something wrong in PEP::PEP()" << RESET << std::endl;	
	}
}


PEP::~PEP() throw()
{
	Guard g(&destroy);
	lerr << logstream::level(10) << "PEP::~PEP()" << logstream::endl;
	
	try {
		
		if(keepalive_task!=NULL) {	//some times we need to force a clean...
			lerr << logstream::level(15) << "PEP::~PEP() canceling keepalive_task!" << logstream::endl;
			keepalive_task->finnished=true;
			keepalive_task->join();
		}
		
		if(connected) {		//clean Exit throw a CLIENT-CLOSE
			connected=false;
			COPSmessage close;	
			socket << close.ClientClose(clientT,COPSError::ShuttingDown);
			if(!solicited.isCanceled())
				solicited.cancel();
			if(!unsolicited.isCanceled())
				unsolicited.cancel();
		}

	} catch (Exception e) {
		lerr << logstream::level(2) << "PEP::~PEP() Exception: " << e.what() << logstream::endl;	
	} catch (...) {
		lerr << logstream::level(2) << "PEP::~PEP() problems...." << logstream::endl;	
	}
	lerr << logstream::level(16) << "PEP::~PEP() DONE" << logstream::endl;
}

void PEP::run() throw() {
	try {
		lerr << logstream::level(2) << "PEP Started" << logstream::endl;	
		
		while(socket.Poll(katime*1000) && connected) {		// we should at least receive a message each KA time or we must be dead :D
			logstream::lerr << logstream::level(7) << "got something" << logstream::endl;
			COPSmessage msg;
			socket >> msg;
		
			switch(msg) {
				case COPSCommonHeader::KEEP_ALIVE: 
					logstream::lerr << logstream::level(3) << "Received KEEP ALIVE from PDP" << logstream::endl;
					keepalive_task->gotKA();
					break;	
				case COPSCommonHeader::CLIENT_CLOSE:
					logstream::lerr << logstream::level(3) << "Received CLIENT CLOSE from PDP" << logstream::endl;
					connected = false;
					throw Socket_Exception("PDP closed remote socket");
					break;
				case COPSCommonHeader::DECISION:
					logstream::lerr << logstream::level(3) << "Received DECISION from PDP" << logstream::endl;
					if(msg.getCOPSCommonHeader().isUnsolicited())
						unsolicited.add(new COPSmessage(msg));
					else
						solicited.add(new COPSmessage(msg));
					break;
				default:
					solicited.add(new COPSmessage(msg));
				
			}		
		}
		logstream::lerr << logstream::level(10) << "Clean Exit from PEP main loop" << logstream::endl;
	} catch (COPSmessage_Exception e) {
		lerr << logstream::level(3) << "Exception " << e.what() << " lead to Close Client" << logstream::endl;
		throw e;
	} catch (Socket_Exception e) {
		lerr << logstream::level(5) << FG_RED << "PEP::run() : " <<  e.what() << RESET << logstream::endl;	
		connected = false;
		try {
			if(!keepalive_task->finnished) {
				keepalive_task->finnished=true;	// no more need for keep alives
				keepalive_task->join();
			}
			lerr << logstream::level(9) << FG_RED << " (done)" << RESET << logstream::endl;	
		} catch (Exception e) {
			lerr << logstream::level(5) << "Exception trying to cancel keep alive : " << e.what() << logstream::endl;
		} catch (...) {
			lerr << logstream::level(5) << "Unknown Exception trying to cancel keep alive : " << logstream::endl;
		}
		solicited.cancel();
		unsolicited.cancel();
	} catch (...) {
		std::cerr << FG_RED << "Something wrong in PEP::run()" << RESET << std::endl;	
	}
	lerr << logstream::level(9) << FG_RED << "PEP::run() all done" << RESET << logstream::endl;	
}

void PEP::Connect(const char *server) 
{
	socket.Connect(server,COPS_IP_PROTOCOL);
	
	COPSmessage open;
	socket << open.ClientOpen(clientT,PepID);
	lerr << logstream::level(2) << "Opened connection with " << server << logstream::endl;
	
	COPSmessage reply;
	socket >> reply;
	
	if(reply==COPSCommonHeader::CLIENT_ACCEPT) {
		lerr << logstream::level(2) << "We were Accepted" << logstream::endl;
		katime = reply.getCOPSKATimer().getKAtime();
		keepalive_task = new PEPKeepAlive(debugLevel,&socket,katime);
		keepalive_task->start();
		connected = true;
	} else throw COPSmessage_Exception(COPSError::BadMessageFormat);
}

COPSmessage PEP::Receive(Inbox &inbox) 
{
	Guard g(&destroy);
	COPSmessage *t = NULL;
	try {
		t = inbox.next();	//next() leaves in charge of freeing t
		COPSmessage m(*t);
		delete t;		//soo lets clean it ;)
		return m;
	} catch(Cancel_Exception e) {
		throw COPSmessage_Exception("Connection with PDP lost");
		/* we expect this since it means PEP exited without leave any message in inbox */
	} catch(Exception e) {
		std::cerr << FG_RED << e.what() << RESET << std::endl;
	} catch (...) {
		std::cerr << FG_RED << "PEP::Receive() big mess" << RESET << std::endl;
	}
	lerr << logstream::level(5) << "PEP::Receive did not find any message in his inbox" << logstream::endl;
	return COPSmessage();
}

void PEP::Send(COPSmessage &msg)
{
	Guard g(&destroy);
	try {
		socket << msg;
	} catch (Socket_Exception e) {
		std::cerr << e.what() << std::endl;
	}
}
