//
// File: COPSLastPDPAddr.h
// Created by: Diogo Gomes <etdgomes@ua.pt>
// Created on: Sun Aug 10 16:40:00 2003
//

#ifndef _COPSLASTPDPADDR_H_
#define _COPSLASTPDPADDR_H_

#include <Copspp/COPSObj.h>

class COPSLastPDPAddr : public COPSObj
{
	public:
		enum AddressType {
			IP4 = 1,
			IP6 = 2
		};
		COPSLastPDPAddr(in_addr *ip4, unsigned short int port);
		COPSLastPDPAddr(in6_addr *ip6, unsigned short int port);
		 ~COPSLastPDPAddr();
		in_addr getIPv4();
		in6_addr getIPv6();
		bool isIPv4();
		bool isIPv6();
		unsigned int getPort() {return port; };
	
	protected:
		unsigned short int port;
		union {
			in_addr ipv4;
			in6_addr ipv6;
		};
	
};


#endif	//_COPSLASTPDPADDR_H_
