//
// File: PDP.h
// Created by: Diogo Gomes <etdgomes@ua.pt>
// Created on: Thu Jul 31 19:10:37 2003
//

#ifndef _PDP_H_
#define _PDP_H_

#include <PThreadsmm/Thread.h>
#include <PThreadsmm/Guard.h>
#include <PThreadsmm/MonitoredQueue.h>
#include <PThreadsmm/Exception.h>

#include <iostream>
#include <map>
#include <queue>

#include <Copspp/SocketServer.h>
#include <Copspp/COPSmessage.h>

#include <Copspp/PDPchild.h>

#define SERVER_TYPE 0xff01
#define KA_TIME 20
#define ACCT_TIME 60

class PDP : public Thread
{
	public:
		PDP(int dbgLevel, std::string address_hook);
		virtual ~PDP() throw();
		virtual void run() throw();
		std::string ClientAccept(Socket *client);
		MonitoredQueue<PDPchild *> unatendedPEP;	
		unsigned int getClientType() {return clientT;};
	
	protected:
		SocketServer socket;
		std::string Address;
		std::map<std::string,PDPchild *> ConnectedPEP;
		unsigned int clientT;
		unsigned int ka_timeout;
		unsigned int acct_time;
	
	private:
		int debugLevel;
		void CleanDeadPEPs();
		void CleanPEP(std::map<std::string, PDPchild *>::iterator p);
};


#endif	//_PDP_H_
