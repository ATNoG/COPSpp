//
// File: SocketClient.cc
// Created by: Diogo Gomes <etdgomes@ua.pt>
// Created on: Thu Jul 31 15:15:55 2003
//

#include "SocketClient.h"


SocketClient::SocketClient() : Socket()
{
}

bool SocketClient::Connect(const char *server, char *port) 
{
	Guard g(&mutex);
	struct addrinfo hints, *res, *res0;
	int error;
	memset(&hints, 0, sizeof(hints));
	hints.ai_family = UNSPEC;
	hints.ai_socktype = STREAM;
	if((error = getaddrinfo(server, port, &hints, &res0))!=0) throw Socket_Exception((char *)gai_strerror(error));

	close(sockfd);
	for (res = res0; res; res = res->ai_next) {
		if((sockfd=socket(res->ai_family, res->ai_socktype,res->ai_protocol))<0) {
			continue;
		}
        if (connect(sockfd, res->ai_addr, res->ai_addrlen) >= 0) {
			freeaddrinfo(res0);
	        return true;
		}
	}
    throw Socket_Exception(strerror(errno));
    freeaddrinfo(res0);
}

SocketClient::~SocketClient()
{
}
