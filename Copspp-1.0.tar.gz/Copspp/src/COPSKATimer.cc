//
// File: COPSKATimer.cc
// Created by: Diogo Gomes <etdgomes@ua.pt>
// Created on: Fri Aug  1 18:18:12 2003
//

#include "COPSKATimer.h"

COPSKATimer::COPSKATimer(unsigned int time) : COPSObj()
{

	size = calculate_padding(sizeof(struct COPSobj_data)+4);  //obj hdr + 4
	KAtime = time;
	data = new char[size];
	memset(data,0,size);

	struct COPSobj_data *obj;
	obj = ((struct COPSobj_data *) data);
	obj->c_num = KATimer;
	obj->c_type = 1;
	obj->obj_len = htons(size);

	KAtime = htons(time);
	memcpy((&data[6]),&KAtime,sizeof(KAtime));	// 6 means hdr + 2 octet offset
	KAtime = time;
	
}


COPSKATimer::~COPSKATimer()
{

}
