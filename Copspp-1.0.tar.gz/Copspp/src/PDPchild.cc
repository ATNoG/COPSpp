//
// File: PDPchild.cc
// Created by: Diogo Gomes <etdgomes@ua.pt>
// Created on: Sun Aug  3 01:24:50 2003
//

#include "PDPchild.h"


PDPchild::PDPchild(int debugLevel, Socket *s, std::string _pepid, unsigned int cT, int t) : Thread()
{
	pepid = _pepid;
	lerr << logstream::setDebugLevel(debugLevel);
	lsyslog	<< logstream::setDebugLevel(debugLevel) << logstream::setIdent((char *)pepid.c_str());
	lerr << logstream::level(1) << "New PEP Connected: " << FG_CYAN << pepid << RESET << logstream::endl;
	lsyslog << logstream::level(1) << "New PEP Connected: " << pepid<< logstream::endl;
	socket = s;
	timeout = t;
	connected = true;
	close = false;
	clientT = cT;
	
}


PDPchild::~PDPchild() throw()
{
	Guard g(&destroy);
	lerr << logstream::level(5) << "PDPchild::~PDPchild()" << logstream::endl;
	if(!inbox.isCanceled())
		inbox.cancel();
	delete socket;
	socket = NULL;
}

void PDPchild::cancel() throw() 
{ 
	Guard g(&destroy);
	inbox.cancel();
	close = true; 
	COPSmessage close;
	lerr << logstream::level(5) << "PDPchild::cancel()" << logstream::endl;
	*socket << close.ClientClose(clientT,COPSError::ShuttingDown);
};

void PDPchild::run() throw() {
	try {
		while(socket!=NULL && socket->Poll(timeout*1000) && !close) {		//timeout for Poll is in miliseconds
			try {
				
				COPSmessage msg;
				*socket >> msg;
			//	std::cerr << msg;
				switch(msg) {
					case COPSCommonHeader::CLIENT_CLOSE:
						lerr << logstream::level(2) << "Received a Client Close" << logstream::endl;
						inbox.add(new COPSmessage(msg));
		//				inbox.cancel(); // Only this early cancel seams to correctly signal the inbox...
						connected = false;
						return;
  					case COPSCommonHeader::KEEP_ALIVE:
						{
							COPSmessage ka;
							*socket<< ka.KeepAlive();
							lerr << logstream::level(3) << "Received a Keep Alive" << logstream::endl;
							break;
						}
					default:
						inbox.add(new COPSmessage(msg));
						break;
				}
				
			} catch (COPSmessage_Exception e) {
				logstream::lerr << logstream::level(5) << "PDPchild::run() : COPSmessage_Exception : " << e.what() << logstream::endl;
			} catch (Socket_Exception e) {
				logstream::lerr << logstream::level(5) << "PDPchild::run() : Socket_Exception : " << e.what() << logstream::endl;
				connected = false;
//				inbox.cancel(); // Only this early cancel seams to correctly signal the inbox...
				return;
			}	
		}
		lerr << logstream::level(2) << "PEP " << FG_CYAN << pepid << RESET << " seams to be dead" << logstream::endl;
		connected = false;
		return;				
	} catch (Socket_Exception e) {
		lerr << logstream::level(4) << "PDPchild::run() : Socket_Exception 2 : " << e.what() << logstream::endl;	
		connected = false;
		if(socket!=NULL)
			socket->Close();
	} catch (Exception e) {
		lerr << logstream::level(4) << "PDPchild::run() : Exception : " << e.what() << logstream::endl;	
	} catch (...) {
		std::cerr << "PDPchild::run() : not supposed to reach this" << logstream::endl;
	}
}

COPSmessage PDPchild::Receive(unsigned long q_timeout) 
{
	Guard g(&destroy);
	COPSmessage *t = NULL;
	try {
		if(q_timeout!=0)
			t = inbox.next(q_timeout);	//next() leaves in charge of freeing t
		else	
			t = inbox.next();	//next() leaves in charge of freeing t

		COPSmessage m(*t);
		delete t;		//soo lets clean it ;)
		return m;
	} catch(BlockingQueue_Exception e) {
		lerr << logstream::level(5) << "PDPchild::Receive : "<< e.what() << logstream::endl;
		throw e;
	} catch(Timeout_Exception t) {
		throw t;
	} catch (...) {
		std::cerr << "PDPchild::Receive() : "<<FG_RED << "big mess" << RESET << std::endl;
	}
	throw COPSmessage_Exception("PDPchild::Receive did not find any message in his inbox");
	
}

void PDPchild::Send(COPSmessage &msg)
{
	Guard g(&destroy);
	try {
		*socket << msg;
		if(msg==COPSCommonHeader::CLIENT_CLOSE) {
			connected = false;
			close = true;
			inbox.cancel(); // Only this early cancel seams to correctly signal the inbox...
		}
	} catch (Socket_Exception e) {
		std::cerr <<"PDPchild::Send() : "<< e.what() << std::endl;
	}
	
}
