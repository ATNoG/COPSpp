//
// File: Socket.h
// Created by: Diogo Gomes <etdgomes@ua.pt>
// Created on: Mon Jul 28 23:45:30 2003
//

#ifndef _SOCKET_H_
#define _SOCKET_H_

#include <string>

#include <sys/types.h>
#include <sys/socket.h>
#include <netdb.h>
#include <errno.h>
#include <unistd.h>
#include <sys/poll.h>

#include <PThreadsmm/Mutex.h>
#include <PThreadsmm/Guard.h>

#include <iostream>

class Socket_Exception
{
	public:
		Socket_Exception(const char *str) {error_msg = str;}
		~Socket_Exception() {};
		const std::string what() {return error_msg; };
	private:
		std::string error_msg;
};

class Socket
{
	public:
	
		enum Domain
		{
			UNIX = PF_UNIX,
			LOCAL = PF_LOCAL,  // Local communication
			INET = PF_INET,		// IPv4 Internet protocols   
			INET6 = PF_INET6,    // IPv6 Internet protocols
			NETLINK = PF_NETLINK, // Kernel user interface device     
			PACKET = PF_PACKET,   // Low level packet interface       
			UNSPEC = PF_UNSPEC	// not specified
		};
		
		enum Type
		{
			STREAM = SOCK_STREAM,
			DGRAM = SOCK_DGRAM,
			SEQPACKET = SOCK_SEQPACKET,
			RAW = SOCK_RAW,
			RDM = SOCK_RDM,
			S_PACKET = SOCK_PACKET
		};

		Socket() throw (Socket_Exception);
		Socket(int socket) throw (Socket_Exception);
		 ~Socket();
		int Receive(std::string &Buffer, unsigned size) throw(Socket_Exception);
		int Receive(void *Buffer, unsigned size) throw(Socket_Exception);
		int TryReceive(void *Buffer, unsigned size) throw(Socket_Exception);
		int Send(std::string Buffer) throw(Socket_Exception);
		int Send(void *Buffer, unsigned size) throw(Socket_Exception);
		bool Socket::Poll(int timeout);		//in miliseconds
		bool Socket::Close() throw(Socket_Exception);
			
	protected:

		Domain domain;
		Type type;
		int protocol;
		Mutex mutex,destroy;
		int sockfd;

};


#endif	//_SOCKET_H_
