//
// File: COPSReportType.h
// Created by: Diogo Gomes <etdgomes@ua.pt>
// Created on: Thu Aug  7 22:54:40 2003
//

#ifndef _COPSREPORTTYPE_H_
#define _COPSREPORTTYPE_H_

#include "COPSObj.h"

class COPSReportType : public COPSObj
{
	public:
		enum Report_Type {
			Success = 1,		// Decision was successful at the PEP
			Failure = 2,		// Decission could not be completed by PEP
			Accounting = 3,
		};
		COPSReportType(Report_Type t);
		COPSReportType(const COPSReportType &);
		COPSReportType &operator=(const COPSReportType &);
		~COPSReportType();
		Report_Type getType() {return type;};
	
	protected:
		Report_Type type;
};


#endif	//_COPSREPORTTYPE_H_
