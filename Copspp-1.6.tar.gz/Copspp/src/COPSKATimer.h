//
// File: COPSKATimer.h
// Created by: Diogo Gomes <etdgomes@ua.pt>
// Created on: Fri Aug  1 18:18:12 2003
//

#ifndef _COPSKATIMER_H_
#define _COPSKATIMER_H_

#include "COPSObj.h"

class COPSKATimer : public COPSObj
{
	public:
		COPSKATimer(unsigned int time);
		COPSKATimer(const COPSKATimer &);
		COPSKATimer &operator=(const COPSKATimer &);
		~COPSKATimer();
		unsigned short getKAtime() {return KAtime;};
	
	protected:
		unsigned short KAtime;
	
};


#endif	//_COPSKATIMER_H_
