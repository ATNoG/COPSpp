//
// File: COPSDecision.cc
// Created by: Diogo Gomes <etdgomes@ua.pt>
// Created on: Thu Aug  7 16:23:15 2003
//

#include "COPSDecision.h"

COPSDecision::COPSDecision(const COPSDecision &obj) : COPSObj(obj) 
{
	#ifdef DEBUG_MAX
	cerr << "COPSDecision::COPSDecision(const COPSDecision &obj)" << endl;
	#endif
	type=obj.type; 
	command=obj.command; 
	Flags=obj.Flags;
};

COPSDecision &COPSDecision::operator=(const COPSDecision &obj)
{
	#ifdef DEBUG_MAX
	cerr << "COPSDecision &COPSDecision::operator=(const COPSDecision &obj)" << endl;
	#endif
	COPSObj::operator=(obj);
	type=obj.type; 
	command=obj.command; 
	Flags=obj.Flags;
	return *this;
}

COPSDecision::COPSDecision(C_Type t, char* d_data, unsigned int d_size) : COPSObj()
{
	#ifdef DEBUG_MAX
	cerr << "COPSDecision::COPSDecision(C_Type t, char* d_data, unsigned int d_size)" << endl;
	#endif
	size = calculate_padding(sizeof(struct COPSobj_data)+d_size);  //obj hdr + 4
	data= new char[size];
	memset(data,0,size);
	
	struct COPSobj_data * obj;
	obj = ((struct COPSobj_data *) data);
	obj->c_num = Decision;
	obj->c_type = t;
	obj->obj_len = htons(size);
	
	type = t;
	command = INVALID;
	Flags = 0;
	memcpy(&data[4],d_data,d_size);
}

COPSDecision::COPSDecision(Command_Code c, unsigned int flgs) : COPSObj()
{
	#ifdef DEBUG_MAX
	cerr << "COPSDecision::COPSDecision(Command_Code c, unsigned int flgs)" << endl;
	#endif
	size = calculate_padding(sizeof(struct COPSobj_data)+4);  //obj hdr + 4
	if(data!=NULL) delete data;
	data= new char[size];
	memset(data,0,size);
	
	struct COPSobj_data * obj;
	obj = ((struct COPSobj_data *) data);
	obj->c_num = Decision;
	obj->c_type = Decision_Flags;
	obj->obj_len = htons(size);
	
	command = (Command_Code) htons(c);
	Flags = htons(flgs);
	memcpy(&data[4],&command,sizeof(command));
	memcpy(&data[6],&Flags,sizeof(Flags));
	
	type = Decision_Flags;
	command = c;
	Flags = 0x01;
	
}

COPSDecision::~COPSDecision()
{

}
